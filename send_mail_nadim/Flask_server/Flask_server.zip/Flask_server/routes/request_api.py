"""The Endpoints to manage the BOOK_REQUESTS"""
import uuid
import requests
import json
from datetime import datetime, timedelta
from flask import jsonify, abort, request, Blueprint

from validate_email import validate_email

REQUEST_API = Blueprint('request_api', __name__)


def get_blueprint():
    """Return the blueprint for the main app module"""
    return REQUEST_API


MAIL = {}


@REQUEST_API.route('/emailmessages', methods=['GET'])
def get_all_email():
    return jsonify(MAIL), 200


@REQUEST_API.route('/emailmessages', methods=['POST'])
def create_new_email():
    if not request.get_json():
        abort(400)

    data = request.get_json(force=True)

    new_uuid = data['externalId']
    MAIL[new_uuid] = data

    return jsonify({"id": new_uuid}), 200
