import connexion
import six

from swagger_server.models.digital_mail_response import DigitalMailResponse  # noqa: E501
from swagger_server.models.eletter_message_request import EletterMessageRequest  # noqa: E501
from swagger_server.models.email_message_list_request import EmailMessageListRequest  # noqa: E501
from swagger_server.models.email_message_request import EmailMessageRequest  # noqa: E501
from swagger_server.models.id_response import IdResponse  # noqa: E501
from swagger_server.models.message_archive import MessageArchive  # noqa: E501
from swagger_server.models.sms_message_request import SmsMessageRequest  # noqa: E501
from swagger_server import util


def get_by_external_id(id):  # noqa: E501
    """Gets a message from the SerializedMessage  by its external id

     # noqa: E501

    :param id: 
    :type id: str

    :rtype: None
    """
    return 'do some magic!'


def get_digital_mail_response_list(ids):  # noqa: E501
    """Get a list of DigitalMailResponse objects, id and operator. Each id corresponds to each id comma separated as a query param. If operator is null, no digital mail service was found for that specific id

     # noqa: E501

    :param ids: Comma separated string of internal or external ids
    :type ids: str

    :rtype: List[DigitalMailResponse]
    """
    return 'do some magic!'


def get_message_by_id(id):  # noqa: E501
    """Gets a message from the archive by its internal or external id

     # noqa: E501

    :param id: Internal or external id
    :type id: str

    :rtype: MessageArchive
    """
    return 'do some magic!'


def get_messages_by_list_of_ids(ids):  # noqa: E501
    """Gets multiple messages from the archive by its internal or external id

     # noqa: E501

    :param ids: comma separated string of internal or external ids
    :type ids: str

    :rtype: List[MessageArchive]
    """
    return 'do some magic!'


def get_statistics(systems=None, types=None, _from=None, to=None):  # noqa: E501
    """get_statistics

     # noqa: E501

    :param systems: 
    :type systems: str
    :param types: 
    :type types: str
    :param _from: 
    :type _from: str
    :param to: 
    :type to: str

    :rtype: None
    """
    return 'do some magic!'


def post_email_message(body=None):  # noqa: E501
    """Creates a  Emails 

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: IdResponse
    """
    if connexion.request.is_json:
        body = EmailMessageListRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def post_message(body=None):  # noqa: E501
    """Creates an Eletter 

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: IdResponse
    """
    if connexion.request.is_json:
        body = EletterMessageRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def post_message_0(body=None):  # noqa: E501
    """Creates an Email 

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: IdResponse
    """
    if connexion.request.is_json:
        body = EmailMessageRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def post_message_1(body=None):  # noqa: E501
    """Creates a Sms 

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: IdResponse
    """
    if connexion.request.is_json:
        body = SmsMessageRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def post_messagelist(body=None):  # noqa: E501
    """Creates a list of Sms 

     # noqa: E501

    :param body: 
    :type body: list | bytes

    :rtype: IdResponse
    """
    if connexion.request.is_json:
        body = [SmsMessageRequest.from_dict(d) for d in connexion.request.get_json()]  # noqa: E501
    return 'do some magic!'
