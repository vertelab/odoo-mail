# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.digital_mail_response import DigitalMailResponse  # noqa: E501
from swagger_server.models.eletter_message_request import EletterMessageRequest  # noqa: E501
from swagger_server.models.email_message_list_request import EmailMessageListRequest  # noqa: E501
from swagger_server.models.email_message_request import EmailMessageRequest  # noqa: E501
from swagger_server.models.id_response import IdResponse  # noqa: E501
from swagger_server.models.message_archive import MessageArchive  # noqa: E501
from swagger_server.models.sms_message_request import SmsMessageRequest  # noqa: E501
from swagger_server.test import BaseTestCase


class TestDefaultController(BaseTestCase):
    """DefaultController integration test stubs"""

    def test_get_by_external_id(self):
        """Test case for get_by_external_id

        Gets a message from the SerializedMessage  by its external id
        """
        response = self.client.open(
            '/nadim/api/failed/{id}'.format(id='id_example'),
            method='GET',
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_digital_mail_response_list(self):
        """Test case for get_digital_mail_response_list

        Get a list of DigitalMailResponse objects, id and operator. Each id corresponds to each id comma separated as a query param. If operator is null, no digital mail service was found for that specific id
        """
        query_string = [('ids', 'ids_example')]
        response = self.client.open(
            '/nadim/api/far',
            method='GET',
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_message_by_id(self):
        """Test case for get_message_by_id

        Gets a message from the archive by its internal or external id
        """
        response = self.client.open(
            '/nadim/api/messagearchiveresource/{id}'.format(id='id_example'),
            method='GET',
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_messages_by_list_of_ids(self):
        """Test case for get_messages_by_list_of_ids

        Gets multiple messages from the archive by its internal or external id
        """
        query_string = [('ids', 'ids_example')]
        response = self.client.open(
            '/nadim/api/messagearchiveresource',
            method='GET',
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_statistics(self):
        """Test case for get_statistics

        
        """
        query_string = [('systems', 'systems_example'),
                        ('types', 'types_example'),
                        ('_from', '_from_example'),
                        ('to', 'to_example')]
        response = self.client.open(
            '/nadim/api/flows',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_email_message(self):
        """Test case for post_email_message

        Creates a  Emails 
        """
        body = EmailMessageListRequest()
        response = self.client.open(
            '/nadim/api/emailmessages/list',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_message(self):
        """Test case for post_message

        Creates an Eletter 
        """
        body = EletterMessageRequest()
        response = self.client.open(
            '/nadim/api/elettermessages',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_message_0(self):
        """Test case for post_message_0

        Creates an Email 
        """
        body = EmailMessageRequest()
        response = self.client.open(
            '/nadim/api/emailmessages',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_message_1(self):
        """Test case for post_message_1

        Creates a Sms 
        """
        body = SmsMessageRequest()
        response = self.client.open(
            '/nadim/api/smsmessages',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_messagelist(self):
        """Test case for post_messagelist

        Creates a list of Sms 
        """
        body = [SmsMessageRequest()]
        response = self.client.open(
            '/nadim/api/smsmessages/list',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
