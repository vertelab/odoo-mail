# swagger_client.DefaultApi

All URIs are relative to *http://nadim.arbetsformedlingen.se/nadim/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_by_external_id**](DefaultApi.md#get_by_external_id) | **GET** /failed/{id} | Gets a message from the SerializedMessage  by its external id
[**get_digital_mail_response_list**](DefaultApi.md#get_digital_mail_response_list) | **GET** /far | Get a list of DigitalMailResponse objects, id and operator. Each id corresponds to each id comma separated as a query param. If operator is null, no digital mail service was found for that specific id
[**get_message_by_id**](DefaultApi.md#get_message_by_id) | **GET** /messagearchiveresource/{id} | Gets a message from the archive by its internal or external id
[**get_messages_by_list_of_ids**](DefaultApi.md#get_messages_by_list_of_ids) | **GET** /messagearchiveresource | Gets multiple messages from the archive by its internal or external id
[**get_statistics**](DefaultApi.md#get_statistics) | **GET** /flows | 
[**post_email_message**](DefaultApi.md#post_email_message) | **POST** /emailmessages/list | Creates a  Emails 
[**post_message**](DefaultApi.md#post_message) | **POST** /elettermessages | Creates an Eletter 
[**post_message_0**](DefaultApi.md#post_message_0) | **POST** /emailmessages | Creates an Email 
[**post_message_1**](DefaultApi.md#post_message_1) | **POST** /smsmessages | Creates a Sms 
[**post_messagelist**](DefaultApi.md#post_messagelist) | **POST** /smsmessages/list | Creates a list of Sms 


# **get_by_external_id**
> get_by_external_id(id)

Gets a message from the SerializedMessage  by its external id



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
id = 'id_example' # str | 

try:
    # Gets a message from the SerializedMessage  by its external id
    api_instance.get_by_external_id(id)
except ApiException as e:
    print("Exception when calling DefaultApi->get_by_external_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_digital_mail_response_list**
> list[DigitalMailResponse] get_digital_mail_response_list(ids)

Get a list of DigitalMailResponse objects, id and operator. Each id corresponds to each id comma separated as a query param. If operator is null, no digital mail service was found for that specific id



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
ids = 'ids_example' # str | Comma separated string of internal or external ids

try:
    # Get a list of DigitalMailResponse objects, id and operator. Each id corresponds to each id comma separated as a query param. If operator is null, no digital mail service was found for that specific id
    api_response = api_instance.get_digital_mail_response_list(ids)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_digital_mail_response_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ids** | **str**| Comma separated string of internal or external ids | 

### Return type

[**list[DigitalMailResponse]**](DigitalMailResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_message_by_id**
> MessageArchive get_message_by_id(id)

Gets a message from the archive by its internal or external id



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
id = 'id_example' # str | Internal or external id

try:
    # Gets a message from the archive by its internal or external id
    api_response = api_instance.get_message_by_id(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_message_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Internal or external id | 

### Return type

[**MessageArchive**](MessageArchive.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_messages_by_list_of_ids**
> list[MessageArchive] get_messages_by_list_of_ids(ids)

Gets multiple messages from the archive by its internal or external id



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
ids = 'ids_example' # str | comma separated string of internal or external ids

try:
    # Gets multiple messages from the archive by its internal or external id
    api_response = api_instance.get_messages_by_list_of_ids(ids)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_messages_by_list_of_ids: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ids** | **str**| comma separated string of internal or external ids | 

### Return type

[**list[MessageArchive]**](MessageArchive.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_statistics**
> get_statistics(systems=systems, types=types, _from=_from, to=to)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
systems = 'systems_example' # str |  (optional)
types = 'types_example' # str |  (optional)
_from = '_from_example' # str |  (optional)
to = 'to_example' # str |  (optional)

try:
    api_instance.get_statistics(systems=systems, types=types, _from=_from, to=to)
except ApiException as e:
    print("Exception when calling DefaultApi->get_statistics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **systems** | **str**|  | [optional] 
 **types** | **str**|  | [optional] 
 **_from** | **str**|  | [optional] 
 **to** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_email_message**
> IdResponse post_email_message(body=body)

Creates a  Emails 



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.EmailMessageListRequest() # EmailMessageListRequest |  (optional)

try:
    # Creates a  Emails 
    api_response = api_instance.post_email_message(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->post_email_message: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EmailMessageListRequest**](EmailMessageListRequest.md)|  | [optional] 

### Return type

[**IdResponse**](IdResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_message**
> IdResponse post_message(body=body)

Creates an Eletter 



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.EletterMessageRequest() # EletterMessageRequest |  (optional)

try:
    # Creates an Eletter 
    api_response = api_instance.post_message(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->post_message: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EletterMessageRequest**](EletterMessageRequest.md)|  | [optional] 

### Return type

[**IdResponse**](IdResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_message_0**
> IdResponse post_message_0(body=body)

Creates an Email 



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.EmailMessageRequest() # EmailMessageRequest |  (optional)

try:
    # Creates an Email 
    api_response = api_instance.post_message_0(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->post_message_0: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EmailMessageRequest**](EmailMessageRequest.md)|  | [optional] 

### Return type

[**IdResponse**](IdResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_message_1**
> IdResponse post_message_1(body=body)

Creates a Sms 



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.SmsMessageRequest() # SmsMessageRequest |  (optional)

try:
    # Creates a Sms 
    api_response = api_instance.post_message_1(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->post_message_1: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SmsMessageRequest**](SmsMessageRequest.md)|  | [optional] 

### Return type

[**IdResponse**](IdResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_messagelist**
> IdResponse post_messagelist(body=body)

Creates a list of Sms 



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = [swagger_client.SmsMessageRequest()] # list[SmsMessageRequest] |  (optional)

try:
    # Creates a list of Sms 
    api_response = api_instance.post_messagelist(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->post_messagelist: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[SmsMessageRequest]**](SmsMessageRequest.md)|  | [optional] 

### Return type

[**IdResponse**](IdResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

