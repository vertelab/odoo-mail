# MessageArchive

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message_id** | **str** |  | [optional] 
**external_id** | **str** |  | [optional] 
**business_system_id** | **int** |  | [optional] 
**message_type_id** | **int** |  | [optional] 
**recipient_id** | **str** |  | [optional] 
**operator_name** | **str** |  | [optional] 
**status_archives** | [**list[StatusArchive]**](StatusArchive.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


