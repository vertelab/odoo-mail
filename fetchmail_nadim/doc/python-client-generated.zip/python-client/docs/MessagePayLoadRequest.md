# MessagePayLoadRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | **str** | A base64 encoded pdf | 
**file_name** | **str** | the filename of the pdf 8 + 3 characters | 
**content_type** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


